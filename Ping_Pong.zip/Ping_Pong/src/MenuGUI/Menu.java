/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MenuGUI;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JPanel;
import ping_pong.Ping_Pong;

/**
 *
 * @author 3gtg
 */
 public class Menu extends JPanel { // Menu Class
    JPanel placeHolder_1;
    JPanel buttonContainer;
    JPanel placeHolder_2;
    
    JButton start;
    JButton end;
    JButton settings;
    JButton info;
    
    Ping_Pong p;
    
    class start_clicked implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent arg0) {
           p.startGame();
        } 
    }
    
    class end_clicked implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent arg0) {
            p.getContentPane().removeAll();
            p.repaint();
            p.validate();
            System.exit(0);
        } 
    }
    
    class info_clicked implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent arg0) {
            System.out.println("Start");
        } 
    }
    
    class settings_clicked implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent arg0) {
            System.out.println("Start");
        } 
    }
    
    
    public Menu(Ping_Pong p)
    {
        this.p = p;
        this.setOpaque(true);
        
        this.setBackground(Color.black);
        this.setLayout(new GridLayout(1,3));
        
        placeHolder_1 = new JPanel();
        placeHolder_1.setLayout(new FlowLayout());
        placeHolder_1.setBackground(Color.black);
        
        placeHolder_2 = new JPanel();
        placeHolder_2.setLayout(new FlowLayout());
        placeHolder_2.setBackground(Color.black);
                
        buttonContainer = new JPanel();
        GridLayout glayout = new GridLayout(4,1);
        glayout.setVgap(40);
        buttonContainer.setBackground(Color.black);
        buttonContainer.setLayout(glayout);
          
        start = new Button();
        start.setText("Zacznij grę");
        start.addActionListener(new start_clicked());
        
        end = new Button();
        end.setText("Zakończ grę");
        end.addActionListener(new end_clicked());
       
        settings = new Button();
        settings.setText("Ustawienia");
        
        info = new Button();
        info.setText("Informacje");
       
        this.add(placeHolder_1);
        this.add(buttonContainer);
        this.add(placeHolder_2);
        buttonContainer.add(start);
        buttonContainer.add(end);
        buttonContainer.add(settings);
        buttonContainer.add(info);
        this.setVisible(true);
        buttonContainer.setVisible(true);
        placeHolder_1.setVisible(true);
        placeHolder_2.setVisible(true);
    }
}