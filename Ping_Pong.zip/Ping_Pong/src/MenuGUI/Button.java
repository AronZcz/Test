/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MenuGUI;

import java.awt.Color;
import java.awt.Font;
import javax.swing.JButton;

/**
 *
 * @author 3gtg
 */
public class Button extends JButton {
    Font font;
    
    public Button()
    {
        font = new Font(Font.DIALOG,  Font.BOLD, 25);
        this.setFont(font);
        this.setBorderPainted(false);
        this.setForeground(Color.black);
        this.setBackground(Color.gray);
    }
    
}
