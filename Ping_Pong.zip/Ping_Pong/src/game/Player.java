/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package game;


import java.awt.Color;
import java.util.logging.Level;
import java.util.logging.Logger;
import ping_pong.Ping_Pong;
/**
 *
 * @author user
 */


public class Player {
    
    
    
    private Vector2D position;
    private Vector2D moveDirection;
   
    private int score;
 
    private Color color;
    
    private boolean moving;
    
 
    private int sensivity;
    private int bounceDirection;
    
    public static final int PLATFORM_WIDTH = 50;
    public static final int PLATFORM_HEIGHT = 100;
   

    public static final  Vector2D VECTOR_UP = new Vector2D(0,-1);
    public static final  Vector2D VECTOR_DOWN =  new Vector2D(0,1);
    
    public static final  Vector2D VECTOR_LEFT = new Vector2D(-1,0);
    public static final  Vector2D VECTOR_RIGHT = new Vector2D(1,0);
    
  
    public Player(int x, int y, Color c, int bounceDirection)
    { 
        this.bounceDirection = bounceDirection;
        position = new Vector2D(x, y);
        color = c;
        score = 0;
        sensivity = 10;
        moveDirection = new Vector2D(0,0);
        moving = false;
    }

   
    public int getX(){ return position.getX(); }
    public int getY(){ return position.getY(); }
    
    public Color getColor(){ return color ;}
    
    public void setPosition(Vector2D v)
    {
       position = v;
    }
    public Vector2D getPosition()
    {
       return position;
    }
    
    public void move(Vector2D v)
    {
       position =position.addVector(v);
    }
    
    public int getBounceDirection()
    {
        return bounceDirection;
    }
    
    public void isCollided(Ball b)
    {
        if(b.getY() >= (position.getY() - Player.PLATFORM_HEIGHT) && b.getY() <= (position.getY() + Player.PLATFORM_HEIGHT))
        {
            if(b.getX() + Ball.RAY >= position.getX()  && b.getX() + Ball.RAY <= position.getX() + Player.PLATFORM_WIDTH  )
            {
                b.bounceDirection = this.bounceDirection;
                b.moveTo(new Vector2D(this.getX() + (Player.PLATFORM_WIDTH * bounceDirection) ,b.getY()));
                System.out.println(position.getX());
              
                    b.bounce(Ball.BOUNCED_FORM_PLAYER);
              
                
            }
            else if(b.getX() >= position.getX()&& b.getX() <= position.getX() + Player.PLATFORM_WIDTH)
            {
                b.bounceDirection = this.bounceDirection;
                b.moveTo(new Vector2D(this.getX() + (Player.PLATFORM_WIDTH * bounceDirection) ,b.getY()));
                System.out.println(position.getX());
            
                    b.bounce(Ball.BOUNCED_FORM_PLAYER);
                
            }
        }
    }
 
    public void addPoint()
    {
        score = score + 1;
    }
    
    public int getScore()
    {
        return score;
    }
    
    public void setDirection(Vector2D v)
    {
        moveDirection = v;
    }
    
    public void go()
    {
        if(!position.equals(moveDirection))
        {
            moving = true;
            if(position.getY() > moveDirection.getY())
            {
                position = position.addVector(Player.VECTOR_UP.scale(sensivity));
            }
            if(position.getY() < moveDirection.getY())
            {
                position = position.addVector(Player.VECTOR_DOWN.scale(sensivity));
            }       
        }
        if(position.equals(moveDirection))
        {
           moving = false;
        }
    }
    
    public void trackBall(Ball b,int delay)
    {
       this.sensivity = delay;
       this.setDirection(new Vector2D(this.getX(),b.getY()));
    }
    
    public boolean isMoving()
    {
       return moving ;
    }
    
}
