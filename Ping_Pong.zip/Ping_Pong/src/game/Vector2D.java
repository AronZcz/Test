/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package game;

/**
 *
 * @author user
 */
public class Vector2D {
    private int x, y;
    
    
    public Vector2D(int x, int y)
    {
        this.x = x;
        this.y = y;
    }
    boolean sameSign(int num1, int num2)
    {
        if (num1 > 0 && num2 < 0)
            return false;
        if (num1 < 0 && num2 > 0)
            return false;
        return true;
    }
    
    public int getX(){ return x; }
    public int getY(){ return y; }
    
    public Vector2D addVector(Vector2D v)
    {
        return new Vector2D(this.x + v.getX(), this.y + v.getY());
    }
    public Vector2D multiplyVector(Vector2D v)
    {
        return new Vector2D(this.x * v.getX(), this.y * v.getY());
    }
            
    public Vector2D scale(int s)
    {
        return new Vector2D(this.x * s, this.y * s);
    }
    @Override
    public String toString()
    {
        return this.x + "," + this.y;
    }
   
    /**
     *
     * @param v
     * @return
     */
    public boolean equals(Vector2D v)
    {
        if(v.getX() == this.x)
        {
            if(v.getY() == this.y)
            {
                return true;
            }
        }
        return false;
    }
}
