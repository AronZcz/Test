/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package game;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JPanel;
import ping_pong.Ping_Pong;


/**
 *
 * @author 3gtg
 */
public class Game extends JPanel {
    Player player_left;
    Player player_right;
    int lastMouseY;
    
    Ping_Pong p;
    Ball ball;
    boolean active;
    
    private class controls extends MouseMotionAdapter
    {
        @Override
        public void mouseMoved(MouseEvent e) {
            super.mouseMoved(e); 
       
            //player_left.setDirection(new Vector2D(player_left.getX(),e.getY()));
           
            if(ball.speed == 0)
            {
                
            }
            if(e.isControlDown())
            {
                ball.start(1);
            } 
            if(e.isShiftDown())
            {
                active = false;
            }
            
            lastMouseY = e.getYOnScreen();
        }
    }

    public Game(Ping_Pong p)
    {
        super.setBackground(Color.black);
        super.setFocusable(true);
        
        this.active = true;   
        this.p = p;
        
        player_left = new Player(20,0, Color.BLUE, 1);
        player_right = new Player(p.getWidth() - (Player.PLATFORM_WIDTH + 40) ,400, Color.RED, -1);  
        
        ball = new Ball(player_right);
        
        super.addMouseMotionListener(new controls());
    }
    
    @Override
    public void paintComponent(Graphics g)
    {
        Graphics2D g2 = (Graphics2D) g;
        super.paintComponent(g);

        g2.setColor(player_left.getColor());
        g2.fillRect(player_left.getX(), player_left.getY(), Player.PLATFORM_WIDTH, Player.PLATFORM_HEIGHT);
        g2.fillRect(player_left.getX(), player_left.getY(), Player.PLATFORM_WIDTH, -Player.PLATFORM_HEIGHT);
        

        g2.setColor(player_right.getColor());
        g2.fillRect(player_right.getX(), player_right.getY(), Player.PLATFORM_WIDTH, Player.PLATFORM_HEIGHT);
        g2.fillRect(player_right.getX(), player_right.getY(), Player.PLATFORM_WIDTH, -Player.PLATFORM_HEIGHT);
        

        g2.setColor(Color.WHITE);
        g2.fillOval(ball.getX(), ball.getY() - Ball.RAY/ 2,Ball.RAY, Ball.RAY);
        
        player_right.isCollided(ball);
        player_left.isCollided(ball);
        
        player_right.trackBall(ball, 11);
        player_left.trackBall(ball, 10);

        ball.edgeCollision(super.getHeight());
        ball.go();
        
        player_left.go();
        player_right.go();
        if(ball.getPosition().getX() < 0)
        {
            player_right.addPoint();
            System.out.println(player_right.getScore());
            ball = new Ball(player_left);
        }
        else if(ball.getPosition().getX() > super.getWidth())
        {
            player_left.addPoint();
            System.out.println(player_left.getScore());
            ball = new Ball(player_right);
        }
        
        try {
            Thread.sleep(9);
        } catch (InterruptedException ex) {
            Logger.getLogger(Game.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
   
    
    public boolean isActive(){return active;}
    
    public void reset()
    {
         active = true;
         ball = new Ball(player_right);
    }
}
