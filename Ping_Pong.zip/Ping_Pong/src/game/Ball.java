/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package game;

/**
 *
 * @author user
 */
public class Ball {
    private Vector2D position;
    
    int bounceDirection;
    int speed;
    
    Vector2D angle;
    
    public static final  Vector2D BOUNCED_FORM_EDGE = new Vector2D(1,-1);
    public static final  Vector2D BOUNCED_FORM_PLAYER = new Vector2D(-1,1);
    public static final  Vector2D BOUNCED_FORM_PLAYER_POWERED = new Vector2D(-1,3);
    
    public static final int RAY = 25;
    
    Player lastPlayer;
    
    public Ball(Player p)
    {
        speed = 0;
        bounceDirection = p.getBounceDirection();
        
        lastPlayer = p;
        
        if(bounceDirection > 0)
        {
            position = new Vector2D(p.getX() + (Player.PLATFORM_WIDTH + 1)  * bounceDirection  , p.getY());
        }
        else {position = new Vector2D(p.getX() - (Ball.RAY + 1) , p.getY());}
       
        angle = new Vector2D(bounceDirection * 4, 2);
    }
    
    public void moveTo(Vector2D v)
    {
       position = v;
    }
    
    public int getX(){ return position.getX(); }
    public int getY(){ return position.getY(); }
    
    public void start(int speed)
    {
        this.speed = speed;
    }
    
    public void stop()
    {
        this.speed = 0;
    }
     
    public void bounce(Vector2D what)
    {
       angle = angle.multiplyVector(what);
       
       if(what.equals(Ball.BOUNCED_FORM_EDGE)){if(speed >= 3){speed -= 1;}}
       if(what.equals(Ball.BOUNCED_FORM_PLAYER)){if(speed < 4){speed += 1;}}
    }
    
    public void go()
    {
       position = position.addVector(angle.scale(speed));
    }
    
    public void edgeCollision(int h)
    {
        if(this.getY() < 0){ this.bounce(Ball.BOUNCED_FORM_EDGE); this.position = (new Vector2D(this.getX(),0)); }
        else if(this.getY() > h) { this.bounce(Ball.BOUNCED_FORM_EDGE); this.position = (new Vector2D(this.getX(), h)); }
    }
    
    public Vector2D getPosition()
    {
        return position;
    }
}

