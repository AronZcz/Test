/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ping_pong;


import game.Game;
import MenuGUI.Menu;
import java.awt.BorderLayout;
import javax.swing.JFrame;
import javax.swing.JPanel;
//import MenuGUI.Menu;



public class Ping_Pong extends JFrame { // Window Class
    //boolean isGameRunning;
    
     // Main JPanels
    JPanel menu;
    Game game;
    JPanel settings;
    
 
    public Ping_Pong() 
    {
        //isGameRunning = false;
        
        super.setSize(1400, 800);
        super.setTitle("Ping-Pong");
        super.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        super.setLayout(new BorderLayout());

        menu = new Menu(this);
        game = new Game(this);

        super.getContentPane().add(menu);
        super.setVisible(true);
    }
    
    public void startGame()
    {
        this.getContentPane().removeAll();
        this.getContentPane().add(game);
        this.validate();
        this.repaint();
        

        runGameLoop();
    }
    
    
    public void endGame()
    {
        this.getContentPane().removeAll();
        this.getContentPane().add(menu);
        this.validate();
        this.repaint();
    }
    
    public static void main(String[] args) {
        Ping_Pong window = new Ping_Pong();
    }
    
     public void runGameLoop() {
        Thread loop = new Thread(() -> {
            while(game.isActive())
            {
                game.repaint(); 
            }
            game.reset();
            Ping_Pong.this.endGame();
        });
        loop.start();
    }

}
